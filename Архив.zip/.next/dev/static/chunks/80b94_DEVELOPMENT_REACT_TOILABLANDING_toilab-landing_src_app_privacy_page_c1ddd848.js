(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/80b94_DEVELOPMENT_REACT_TOILABLANDING_toilab-landing_src_app_privacy_page_5f2e6dee.js"
],
    source: "dynamic"
});
