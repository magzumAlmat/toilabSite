(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_2099bd0f._.js",
  "static/chunks/eac11_next_dist_compiled_react-dom_f5741f08._.js",
  "static/chunks/eac11_next_dist_compiled_react-server-dom-turbopack_99f8b662._.js",
  "static/chunks/eac11_next_dist_compiled_next-devtools_index_6628165b.js",
  "static/chunks/eac11_next_dist_compiled_5d8e0131._.js",
  "static/chunks/eac11_next_dist_client_02db0f87._.js",
  "static/chunks/eac11_next_dist_098e5863._.js",
  "static/chunks/eac11_@swc_helpers_cjs_6ffee8b2._.js"
],
    source: "entry"
});
