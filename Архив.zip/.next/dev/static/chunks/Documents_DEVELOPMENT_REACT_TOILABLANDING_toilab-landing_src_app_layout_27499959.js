(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/eac11_7f7a8489._.js",
  "static/chunks/Documents_DEVELOPMENT_REACT_TOILABLANDING_toilab-landing_src_app_layout_0d40f7cc.js",
  "static/chunks/80b94_DEVELOPMENT_REACT_TOILABLANDING_toilab-landing_src_app_globals_97ca9b18.css"
],
    source: "dynamic"
});
