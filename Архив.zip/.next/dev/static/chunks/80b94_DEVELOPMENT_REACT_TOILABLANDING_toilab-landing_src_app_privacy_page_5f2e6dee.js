(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/privacy/page.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// app/privacy/page.js
__turbopack_context__.s([
    "default",
    ()=>Privacy
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$src$2f$app$2f$layout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function Privacy() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "10c603b3e8b80584a77284a4de7d399d1547c6d587e1e2ba6abc87233b9f3af3") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "10c603b3e8b80584a77284a4de7d399d1547c6d587e1e2ba6abc87233b9f3af3";
    }
    const { lang } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$src$2f$app$2f$layout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LangContext"]);
    const t = lang === "ru" ? ru : kz;
    let t0;
    if ($[1] !== t.title) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "text-5xl font-black text-center mb-12",
            children: t.title
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/privacy/page.js",
            lineNumber: 21,
            columnNumber: 10
        }, this);
        $[1] = t.title;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    let t1;
    if ($[3] !== t.text) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            children: t.text
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/privacy/page.js",
            lineNumber: 29,
            columnNumber: 10
        }, this);
        $[3] = t.text;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    let t2;
    if ($[5] !== t.request) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            children: t.request
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/privacy/page.js",
            lineNumber: 37,
            columnNumber: 10
        }, this);
        $[5] = t.request;
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    let t3;
    if ($[7] !== t.updated) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-sm text-gray-500 text-center mt-10",
            children: t.updated
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/privacy/page.js",
            lineNumber: 45,
            columnNumber: 10
        }, this);
        $[7] = t.updated;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    let t4;
    if ($[9] !== t1 || $[10] !== t2 || $[11] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "prose prose-lg mx-auto text-gray-700 max-w-3xl",
            children: [
                t1,
                t2,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/privacy/page.js",
            lineNumber: 53,
            columnNumber: 10
        }, this);
        $[9] = t1;
        $[10] = t2;
        $[11] = t3;
        $[12] = t4;
    } else {
        t4 = $[12];
    }
    let t5;
    if ($[13] !== t0 || $[14] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-24 px-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-5xl mx-auto",
                children: [
                    t0,
                    t4
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/privacy/page.js",
                lineNumber: 63,
                columnNumber: 42
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/privacy/page.js",
            lineNumber: 63,
            columnNumber: 10
        }, this);
        $[13] = t0;
        $[14] = t4;
        $[15] = t5;
    } else {
        t5 = $[15];
    }
    return t5;
}
_s(Privacy, "3fHXCzwIbOHzGYVYP4JiDP/Kgk8=");
_c = Privacy;
const ru = {
    title: "Политика конфиденциальности",
    text: "Мы собираем только необходимые данные для работы приложения: имя, телефон, email. Все данные защищены и не передаются третьим лицам без вашего согласия.",
    request: "Вы можете запросить удаление данных в любой момент, написав на support@toilab.kz.",
    updated: "Последнее обновление: 11 ноября 2025 г."
};
const kz = {
    title: "Құпиялылық саясаты",
    text: "Біз тек қолданбаның жұмысына қажетті деректерді жинаймыз: аты, телефон, email. Барлық деректер қорғалған және сіздің келісімсіз үшінші тұлғаларға берілмейді.",
    request: "Деректерді кез келген уақытта жоюды сұрай аласыз, support@toilab.kz жазыңыз.",
    updated: "Соңғы жаңарту: 2025 жылғы 11 қараша"
};
var _c;
__turbopack_context__.k.register(_c, "Privacy");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=80b94_DEVELOPMENT_REACT_TOILABLANDING_toilab-landing_src_app_privacy_page_5f2e6dee.js.map