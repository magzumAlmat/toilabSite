module.exports = [
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// app/page.js
__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/download.js [app-ssr] (ecmascript) <export default as Download>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-ssr] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/search.js [app-ssr] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/star.js [app-ssr] (ecmascript) <export default as Star>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/calendar.js [app-ssr] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Wallet$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/wallet.js [app-ssr] (ecmascript) <export default as Wallet>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-ssr] (ecmascript) <export default as MessageCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$smartphone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Smartphone$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/smartphone.js [app-ssr] (ecmascript) <export default as Smartphone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$src$2f$app$2f$layout$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
const Ornament = ({ className = "" })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        className: `w-full ${className}`,
        viewBox: "0 0 1200 100",
        preserveAspectRatio: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M0,50 Q100,20 200,50 T400,50 T600,50 T800,50 T1000,50 T1200,50",
                stroke: "#4A3F35",
                strokeWidth: "6",
                fill: "none"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 12,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M0,50 Q100,80 200,50 T400,50 T600,50 T800,50 T1000,50 T1200,50",
                stroke: "#4A3F35",
                strokeWidth: "6",
                fill: "none"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 14,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M50,35 Q75,25 100,35 T150,35",
                stroke: "#4A3F35",
                strokeWidth: "4",
                fill: "none"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 16,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M150,65 Q175,75 200,65 T250,65",
                stroke: "#4A3F35",
                strokeWidth: "4",
                fill: "none"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 18,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M250,35 Q275,25 300,35 T350,35",
                stroke: "#4A3F35",
                strokeWidth: "4",
                fill: "none"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 20,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M350,65 Q375,75 400,65 T450,65",
                stroke: "#4A3F35",
                strokeWidth: "4",
                fill: "none"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 22,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M450,35 Q475,25 500,35 T550,35",
                stroke: "#4A3F35",
                strokeWidth: "4",
                fill: "none"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 24,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M550,65 Q575,75 600,65 T650,65",
                stroke: "#4A3F35",
                strokeWidth: "4",
                fill: "none"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 26,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M650,35 Q675,25 700,35 T750,35",
                stroke: "#4A3F35",
                strokeWidth: "4",
                fill: "none"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 28,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M750,65 Q775,75 800,65 T850,65",
                stroke: "#4A3F35",
                strokeWidth: "4",
                fill: "none"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 30,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M850,35 Q875,25 900,35 T950,35",
                stroke: "#4A3F35",
                strokeWidth: "4",
                fill: "none"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 32,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M950,65 Q975,75 1000,65 T1050,65",
                stroke: "#4A3F35",
                strokeWidth: "4",
                fill: "none"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 34,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M1050,35 Q1075,25 1100,35 T1150,35",
                stroke: "#4A3F35",
                strokeWidth: "4",
                fill: "none"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 36,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
        lineNumber: 11,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
function Home() {
    const { lang } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$src$2f$app$2f$layout$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LangContext"]);
    const t = lang === 'ru' ? ru : kz;
    const scrollToFeatures = ()=>{
        document.getElementById('features')?.scrollIntoView({
            behavior: 'smooth'
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "pt-16 pb-28 px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-7xl mx-auto text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-6xl md:text-8xl font-black mb-8 leading-tight",
                            children: [
                                t.hero.title[0],
                                " ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                                    lineNumber: 62,
                                    columnNumber: 31
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-[#8C7B6D]",
                                    children: t.hero.title[1]
                                }, void 0, false, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                                    lineNumber: 63,
                                    columnNumber: 13
                                }, this),
                                " ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                                    lineNumber: 63,
                                    columnNumber: 71
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-[#4A3F35]",
                                    children: t.hero.title[2]
                                }, void 0, false, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                                    lineNumber: 64,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                            lineNumber: 61,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-2xl md:text-3xl mb-12 max-w-4xl mx-auto font-medium leading-relaxed",
                            children: t.hero.subtitle
                        }, void 0, false, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                            lineNumber: 71,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col sm:flex-row gap-6 justify-center items-center mb-16",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: "https://play.google.com/store/apps",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "bg-[#4A3F35] text-white px-10 py-5 rounded-full flex items-center gap-4 text-2xl font-bold hover:bg-[#3A3028] transition shadow-2xl",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                            size: 36
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                                            lineNumber: 78,
                                            columnNumber: 15
                                        }, this),
                                        " Google Play"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                                    lineNumber: 76,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: "https://apps.apple.com",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "bg-[#4A3F35] text-white px-10 py-5 rounded-full flex items-center gap-4 text-2xl font-bold hover:bg-[#3A3028] transition shadow-2xl",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                            size: 36
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                                            lineNumber: 82,
                                            columnNumber: 15
                                        }, this),
                                        " App Store"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                                    lineNumber: 80,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                            lineNumber: 75,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: scrollToFeatures,
                            className: "animate-bounce",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                size: 56,
                                className: "mx-auto text-[#8C7B6D]"
                            }, void 0, false, {
                                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                                lineNumber: 87,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                            lineNumber: 86,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 60,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 59,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                id: "features",
                className: "py-20 bg-[#4A3F35] text-[#F5F0E9] px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-7xl mx-auto",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-5xl font-black text-center mb-16",
                            children: t.features.title
                        }, void 0, false, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                            lineNumber: 95,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid md:grid-cols-2 lg:grid-cols-3 gap-10",
                            children: t.features.items.map((f, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-[#F5F0E9]/10 backdrop-blur-lg rounded-3xl p-8 text-center hover:scale-105 transition",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mx-auto mb-6 w-20 h-20 bg-[#8C7B6D]/20 rounded-full flex items-center justify-center",
                                            children: f.icon
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                                            lineNumber: 99,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-2xl font-bold mb-4",
                                            children: f.title
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                                            lineNumber: 100,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-lg opacity-90",
                                            children: f.desc
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                                            lineNumber: 101,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, i, true, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                                    lineNumber: 98,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                            lineNumber: 96,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 94,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 93,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "py-24 bg-[#F5F0E9] px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-6xl mx-auto text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-5xl font-black mb-16",
                            children: t.screenshots.title
                        }, void 0, false, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                            lineNumber: 111,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            src: "/mockup-solution.png",
                            alt: "ToiLab интерфейс",
                            width: 440,
                            height: 900,
                            className: "rounded-3xl shadow-2xl border-8 border-white mx-auto"
                        }, void 0, false, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                            lineNumber: 112,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 110,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 109,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "py-32 bg-gradient-to-t from-[#4A3F35] to-[#6B5A4D] text-[#F5F0E9] text-center px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-4xl mx-auto",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-6xl font-black mb-10",
                            children: t.cta.title
                        }, void 0, false, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                            lineNumber: 119,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-3xl mb-16 whitespace-pre-line",
                            children: t.cta.subtitle
                        }, void 0, false, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                            lineNumber: 120,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            src: "/toilab-logo-full.png",
                            alt: "ToiLab",
                            width: 480,
                            height: 240,
                            className: "mx-auto mb-12"
                        }, void 0, false, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                            lineNumber: 121,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col sm:flex-row gap-8 justify-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: "https://play.google.com/store/apps",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "bg-[#F5F0E9] text-[#4A3F35] px-14 py-7 rounded-full text-3xl font-black hover:bg-white transition shadow-2xl",
                                    children: "Google Play"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                                    lineNumber: 123,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: "https://apps.apple.com",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "bg-[#F5F0E9] text-[#4A3F35] px-14 py-7 rounded-full text-3xl font-black hover:bg-white transition shadow-2xl",
                                    children: "App Store"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                                    lineNumber: 124,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                            lineNumber: 122,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 118,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 117,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
// Тексты главной
const ru = {
    hero: {
        title: [
            "Каждый Той",
            "Особенным",
            "Пусть Будет!"
        ],
        subtitle: "ToiLab — всё для свадьбы в одном приложении: ресторан, фотограф, ведущий, фейерверк, рассрочка и даже микрокредит."
    },
    features: {
        title: "Что умеет ToiLab?",
        items: [
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 136,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "1000+ услуг",
                desc: "Рестораны, фотографы, ведущие, декор"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 137,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Реальные отзывы",
                desc: "Только проверенные рейтинги"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 138,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Бронь за 2 минуты",
                desc: "Прямо в приложении"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Wallet$3e$__["Wallet"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 139,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Рассрочка",
                desc: "60% клиентов выбирают"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__["MessageCircle"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 140,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Чат с подрядчиком",
                desc: "Договор в приложении"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$smartphone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Smartphone$3e$__["Smartphone"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 141,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Свадьба в телефоне",
                desc: "Все заказы в одном месте"
            }
        ]
    },
    screenshots: {
        title: "Как выглядит приложение"
    },
    cta: {
        title: "Скачайте ToiLab",
        subtitle: "Бронируйте, оплачивайте, берите в рассрочку — за 2 минуты."
    }
};
const kz = {
    hero: {
        title: [
            "Әрбір Той",
            "Ерекше",
            "Болсын!"
        ],
        subtitle: "ToiLab — тойға қажетті барлық нәрсе бір қолданбада: мейрамхана, фотограф, ведущий, фейерверк, бөліп төлеу және микрокредит."
    },
    features: {
        title: "ToiLab немен көмектеседі?",
        items: [
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 150,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "1000+ қызмет",
                desc: "Мейрамханалар, фотографтар, ведущийлар, декор"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 151,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Нақты пікірлер",
                desc: "Тек расталған рейтингтер"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 152,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "2 минутта брондау",
                desc: "Тікелей қолданбада"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Wallet$3e$__["Wallet"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 153,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Бөліп төлеу",
                desc: "Клиенттердің 60%-ы таңдайды"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__["MessageCircle"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 154,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Подрядчикпен чат",
                desc: "Келісімшарт қолданбада"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$smartphone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Smartphone$3e$__["Smartphone"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 155,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Той телефонда",
                desc: "Барлық тапсырыстар бір жерде"
            }
        ]
    },
    screenshots: {
        title: "Қолданба қалай көрінеді"
    },
    cta: {
        title: "ToiLab жүктеп алыңыз",
        subtitle: "Брондаңыз, төлеңіз, бөліп төлеңіз — 2 минутта."
    }
};
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/download.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Download
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-ssr] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M12 15V3",
            key: "m9g1x1"
        }
    ],
    [
        "path",
        {
            d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
            key: "ih7n3h"
        }
    ],
    [
        "path",
        {
            d: "m7 10 5 5 5-5",
            key: "brsn70"
        }
    ]
];
const Download = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("download", __iconNode);
;
 //# sourceMappingURL=download.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/download.js [app-ssr] (ecmascript) <export default as Download>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Download",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/download.js [app-ssr] (ecmascript)");
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>ChevronDown
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-ssr] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "m6 9 6 6 6-6",
            key: "qrunsl"
        }
    ]
];
const ChevronDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("chevron-down", __iconNode);
;
 //# sourceMappingURL=chevron-down.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-ssr] (ecmascript) <export default as ChevronDown>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChevronDown",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-ssr] (ecmascript)");
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/search.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Search
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-ssr] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "m21 21-4.34-4.34",
            key: "14j7rj"
        }
    ],
    [
        "circle",
        {
            cx: "11",
            cy: "11",
            r: "8",
            key: "4ej97u"
        }
    ]
];
const Search = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("search", __iconNode);
;
 //# sourceMappingURL=search.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/search.js [app-ssr] (ecmascript) <export default as Search>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Search",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/search.js [app-ssr] (ecmascript)");
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/star.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Star
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-ssr] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
            key: "r04s7s"
        }
    ]
];
const Star = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("star", __iconNode);
;
 //# sourceMappingURL=star.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/star.js [app-ssr] (ecmascript) <export default as Star>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Star",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/star.js [app-ssr] (ecmascript)");
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/calendar.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Calendar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-ssr] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M8 2v4",
            key: "1cmpym"
        }
    ],
    [
        "path",
        {
            d: "M16 2v4",
            key: "4m81vk"
        }
    ],
    [
        "rect",
        {
            width: "18",
            height: "18",
            x: "3",
            y: "4",
            rx: "2",
            key: "1hopcy"
        }
    ],
    [
        "path",
        {
            d: "M3 10h18",
            key: "8toen8"
        }
    ]
];
const Calendar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("calendar", __iconNode);
;
 //# sourceMappingURL=calendar.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/calendar.js [app-ssr] (ecmascript) <export default as Calendar>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Calendar",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/calendar.js [app-ssr] (ecmascript)");
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/wallet.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Wallet
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-ssr] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",
            key: "18etb6"
        }
    ],
    [
        "path",
        {
            d: "M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4",
            key: "xoc0q4"
        }
    ]
];
const Wallet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("wallet", __iconNode);
;
 //# sourceMappingURL=wallet.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/wallet.js [app-ssr] (ecmascript) <export default as Wallet>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Wallet",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wallet$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/wallet.js [app-ssr] (ecmascript)");
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>MessageCircle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-ssr] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
            key: "1sd12s"
        }
    ]
];
const MessageCircle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("message-circle", __iconNode);
;
 //# sourceMappingURL=message-circle.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-ssr] (ecmascript) <export default as MessageCircle>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MessageCircle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-ssr] (ecmascript)");
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/smartphone.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Smartphone
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-ssr] (ecmascript)");
;
const __iconNode = [
    [
        "rect",
        {
            width: "14",
            height: "20",
            x: "5",
            y: "2",
            rx: "2",
            ry: "2",
            key: "1yt0o3"
        }
    ],
    [
        "path",
        {
            d: "M12 18h.01",
            key: "mhygvu"
        }
    ]
];
const Smartphone = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("smartphone", __iconNode);
;
 //# sourceMappingURL=smartphone.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/smartphone.js [app-ssr] (ecmascript) <export default as Smartphone>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Smartphone",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$smartphone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$smartphone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/smartphone.js [app-ssr] (ecmascript)");
}),
];

//# sourceMappingURL=Documents_DEVELOPMENT_REACT_TOILABLANDING_toilab-landing_47346763._.js.map