(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/eac11_6170c8c8._.js",
  "static/chunks/80b94_DEVELOPMENT_REACT_TOILABLANDING_toilab-landing_src_app_ToiLabLanding_2499e2f1.js"
],
    source: "dynamic"
});
