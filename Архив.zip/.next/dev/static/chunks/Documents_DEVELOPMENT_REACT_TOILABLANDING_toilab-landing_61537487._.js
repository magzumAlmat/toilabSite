(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// app/page.js
__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/download.js [app-client] (ecmascript) <export default as Download>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/star.js [app-client] (ecmascript) <export default as Star>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Wallet$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/wallet.js [app-client] (ecmascript) <export default as Wallet>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-client] (ecmascript) <export default as MessageCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$smartphone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Smartphone$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/smartphone.js [app-client] (ecmascript) <export default as Smartphone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$src$2f$app$2f$layout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const Ornament = (t0)=>{
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "bbc6e166d8244ee074983f94e2fba325bc6b51d3f0a511b559bc5f0f310c666b") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "bbc6e166d8244ee074983f94e2fba325bc6b51d3f0a511b559bc5f0f310c666b";
    }
    const { className: t1 } = t0;
    const className = t1 === undefined ? "" : t1;
    const t2 = `w-full ${className}`;
    let t10;
    let t11;
    let t12;
    let t13;
    let t14;
    let t15;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M0,50 Q100,20 200,50 T400,50 T600,50 T800,50 T1000,50 T1200,50",
            stroke: "#4A3F35",
            strokeWidth: "6",
            fill: "none"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 36,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M0,50 Q100,80 200,50 T400,50 T600,50 T800,50 T1000,50 T1200,50",
            stroke: "#4A3F35",
            strokeWidth: "6",
            fill: "none"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 37,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M50,35 Q75,25 100,35 T150,35",
            stroke: "#4A3F35",
            strokeWidth: "4",
            fill: "none"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 38,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M150,65 Q175,75 200,65 T250,65",
            stroke: "#4A3F35",
            strokeWidth: "4",
            fill: "none"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 39,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M250,35 Q275,25 300,35 T350,35",
            stroke: "#4A3F35",
            strokeWidth: "4",
            fill: "none"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 40,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M350,65 Q375,75 400,65 T450,65",
            stroke: "#4A3F35",
            strokeWidth: "4",
            fill: "none"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 41,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M450,35 Q475,25 500,35 T550,35",
            stroke: "#4A3F35",
            strokeWidth: "4",
            fill: "none"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 42,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M550,65 Q575,75 600,65 T650,65",
            stroke: "#4A3F35",
            strokeWidth: "4",
            fill: "none"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 43,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M650,35 Q675,25 700,35 T750,35",
            stroke: "#4A3F35",
            strokeWidth: "4",
            fill: "none"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 44,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M750,65 Q775,75 800,65 T850,65",
            stroke: "#4A3F35",
            strokeWidth: "4",
            fill: "none"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 45,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M850,35 Q875,25 900,35 T950,35",
            stroke: "#4A3F35",
            strokeWidth: "4",
            fill: "none"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 46,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M950,65 Q975,75 1000,65 T1050,65",
            stroke: "#4A3F35",
            strokeWidth: "4",
            fill: "none"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 47,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M1050,35 Q1075,25 1100,35 T1150,35",
            stroke: "#4A3F35",
            strokeWidth: "4",
            fill: "none"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 48,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[1] = t10;
        $[2] = t11;
        $[3] = t12;
        $[4] = t13;
        $[5] = t14;
        $[6] = t15;
        $[7] = t3;
        $[8] = t4;
        $[9] = t5;
        $[10] = t6;
        $[11] = t7;
        $[12] = t8;
        $[13] = t9;
    } else {
        t10 = $[1];
        t11 = $[2];
        t12 = $[3];
        t13 = $[4];
        t14 = $[5];
        t15 = $[6];
        t3 = $[7];
        t4 = $[8];
        t5 = $[9];
        t6 = $[10];
        t7 = $[11];
        t8 = $[12];
        t9 = $[13];
    }
    let t16;
    if ($[14] !== t2) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: t2,
            viewBox: "0 0 1200 100",
            preserveAspectRatio: "none",
            xmlns: "http://www.w3.org/2000/svg",
            children: [
                t3,
                t4,
                t5,
                t6,
                t7,
                t8,
                t9,
                t10,
                t11,
                t12,
                t13,
                t14,
                t15
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 79,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[14] = t2;
        $[15] = t16;
    } else {
        t16 = $[15];
    }
    return t16;
};
_c = Ornament;
function Home() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(47);
    if ($[0] !== "bbc6e166d8244ee074983f94e2fba325bc6b51d3f0a511b559bc5f0f310c666b") {
        for(let $i = 0; $i < 47; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "bbc6e166d8244ee074983f94e2fba325bc6b51d3f0a511b559bc5f0f310c666b";
    }
    const { lang } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$src$2f$app$2f$layout$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LangContext"]);
    const t = lang === "ru" ? ru : kz;
    const scrollToFeatures = _HomeScrollToFeatures;
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 102,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] !== t.hero.title[1]) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-[#8C7B6D]",
            children: t.hero.title[1]
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 109,
            columnNumber: 10
        }, this);
        $[2] = t.hero.title[1];
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    let t2;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 117,
            columnNumber: 10
        }, this);
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    let t3;
    if ($[5] !== t.hero.title[2]) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-[#4A3F35]",
            children: t.hero.title[2]
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 124,
            columnNumber: 10
        }, this);
        $[5] = t.hero.title[2];
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== t.hero.title[0] || $[8] !== t1 || $[9] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "text-6xl md:text-8xl font-black mb-8 leading-tight",
            children: [
                t.hero.title[0],
                " ",
                t0,
                t1,
                " ",
                t2,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 132,
            columnNumber: 10
        }, this);
        $[7] = t.hero.title[0];
        $[8] = t1;
        $[9] = t3;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    let t5;
    if ($[11] !== t.hero.subtitle) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-2xl md:text-3xl mb-12 max-w-4xl mx-auto font-medium leading-relaxed",
            children: t.hero.subtitle
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 142,
            columnNumber: 10
        }, this);
        $[11] = t.hero.subtitle;
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    let t6;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            href: "https://play.google.com/store/apps",
            target: "_blank",
            rel: "noopener noreferrer",
            className: "bg-[#4A3F35] text-white px-10 py-5 rounded-full flex items-center gap-4 text-2xl font-bold hover:bg-[#3A3028] transition shadow-2xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                    size: 36
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 150,
                    columnNumber: 241
                }, this),
                " Google Play"
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 150,
            columnNumber: 10
        }, this);
        $[13] = t6;
    } else {
        t6 = $[13];
    }
    let t7;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col sm:flex-row gap-6 justify-center items-center mb-16",
            children: [
                t6,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    href: "https://apps.apple.com",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className: "bg-[#4A3F35] text-white px-10 py-5 rounded-full flex items-center gap-4 text-2xl font-bold hover:bg-[#3A3028] transition shadow-2xl",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                            size: 36
                        }, void 0, false, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                            lineNumber: 157,
                            columnNumber: 316
                        }, this),
                        " App Store"
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 157,
                    columnNumber: 97
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 157,
            columnNumber: 10
        }, this);
        $[14] = t7;
    } else {
        t7 = $[14];
    }
    let t8;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: scrollToFeatures,
            className: "animate-bounce",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                size: 56,
                className: "mx-auto text-[#8C7B6D]"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 164,
                columnNumber: 72
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 164,
            columnNumber: 10
        }, this);
        $[15] = t8;
    } else {
        t8 = $[15];
    }
    let t9;
    if ($[16] !== t4 || $[17] !== t5) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "pt-16 pb-28 px-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-7xl mx-auto text-center",
                children: [
                    t4,
                    t5,
                    t7,
                    t8
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 171,
                columnNumber: 48
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 171,
            columnNumber: 10
        }, this);
        $[16] = t4;
        $[17] = t5;
        $[18] = t9;
    } else {
        t9 = $[18];
    }
    let t10;
    if ($[19] !== t.features.title) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-5xl font-black text-center mb-16",
            children: t.features.title
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 180,
            columnNumber: 11
        }, this);
        $[19] = t.features.title;
        $[20] = t10;
    } else {
        t10 = $[20];
    }
    let t11;
    if ($[21] !== t.features.items) {
        t11 = t.features.items.map(_HomeTFeaturesItemsMap);
        $[21] = t.features.items;
        $[22] = t11;
    } else {
        t11 = $[22];
    }
    let t12;
    if ($[23] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid md:grid-cols-2 lg:grid-cols-3 gap-10",
            children: t11
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 196,
            columnNumber: 11
        }, this);
        $[23] = t11;
        $[24] = t12;
    } else {
        t12 = $[24];
    }
    let t13;
    if ($[25] !== t10 || $[26] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            id: "features",
            className: "py-20 bg-[#4A3F35] text-[#F5F0E9] px-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-7xl mx-auto",
                children: [
                    t10,
                    t12
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 204,
                columnNumber: 85
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 204,
            columnNumber: 11
        }, this);
        $[25] = t10;
        $[26] = t12;
        $[27] = t13;
    } else {
        t13 = $[27];
    }
    let t14;
    if ($[28] !== t.screenshots.title) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-5xl font-black mb-16",
            children: t.screenshots.title
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 213,
            columnNumber: 11
        }, this);
        $[28] = t.screenshots.title;
        $[29] = t14;
    } else {
        t14 = $[29];
    }
    let t15;
    if ($[30] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            src: "/mockup-solution.png",
            alt: "ToiLab \u0438\u043D\u0442\u0435\u0440\u0444\u0435\u0439\u0441",
            width: 440,
            height: 900,
            className: "rounded-3xl shadow-2xl border-8 border-white mx-auto"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 221,
            columnNumber: 11
        }, this);
        $[30] = t15;
    } else {
        t15 = $[30];
    }
    let t16;
    if ($[31] !== t14) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-24 bg-[#F5F0E9] px-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-6xl mx-auto text-center",
                children: [
                    t14,
                    t15
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 228,
                columnNumber: 56
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 228,
            columnNumber: 11
        }, this);
        $[31] = t14;
        $[32] = t16;
    } else {
        t16 = $[32];
    }
    let t17;
    if ($[33] !== t.cta.title) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-6xl font-black mb-10",
            children: t.cta.title
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 236,
            columnNumber: 11
        }, this);
        $[33] = t.cta.title;
        $[34] = t17;
    } else {
        t17 = $[34];
    }
    let t18;
    if ($[35] !== t.cta.subtitle) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-3xl mb-16 whitespace-pre-line",
            children: t.cta.subtitle
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 244,
            columnNumber: 11
        }, this);
        $[35] = t.cta.subtitle;
        $[36] = t18;
    } else {
        t18 = $[36];
    }
    let t19;
    if ($[37] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            src: "/toilab-logo-full.png",
            alt: "ToiLab",
            width: 480,
            height: 240,
            className: "mx-auto mb-12"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 252,
            columnNumber: 11
        }, this);
        $[37] = t19;
    } else {
        t19 = $[37];
    }
    let t20;
    if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col sm:flex-row gap-8 justify-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    href: "https://play.google.com/store/apps",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className: "bg-[#F5F0E9] text-[#4A3F35] px-14 py-7 rounded-full text-3xl font-black hover:bg-white transition shadow-2xl",
                    children: "Google Play"
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 259,
                    columnNumber: 75
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    href: "https://apps.apple.com",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className: "bg-[#F5F0E9] text-[#4A3F35] px-14 py-7 rounded-full text-3xl font-black hover:bg-white transition shadow-2xl",
                    children: "App Store"
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 259,
                    columnNumber: 298
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 259,
            columnNumber: 11
        }, this);
        $[38] = t20;
    } else {
        t20 = $[38];
    }
    let t21;
    if ($[39] !== t17 || $[40] !== t18) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "py-32 bg-gradient-to-t from-[#4A3F35] to-[#6B5A4D] text-[#F5F0E9] text-center px-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-4xl mx-auto",
                children: [
                    t17,
                    t18,
                    t19,
                    t20
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 266,
                columnNumber: 115
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
            lineNumber: 266,
            columnNumber: 11
        }, this);
        $[39] = t17;
        $[40] = t18;
        $[41] = t21;
    } else {
        t21 = $[41];
    }
    let t22;
    if ($[42] !== t13 || $[43] !== t16 || $[44] !== t21 || $[45] !== t9) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t9,
                t13,
                t16,
                t21
            ]
        }, void 0, true);
        $[42] = t13;
        $[43] = t16;
        $[44] = t21;
        $[45] = t9;
        $[46] = t22;
    } else {
        t22 = $[46];
    }
    return t22;
}
_s(Home, "3fHXCzwIbOHzGYVYP4JiDP/Kgk8=");
_c1 = Home;
// Тексты главной
function _HomeTFeaturesItemsMap(f, i) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-[#F5F0E9]/10 backdrop-blur-lg rounded-3xl p-8 text-center hover:scale-105 transition",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mx-auto mb-6 w-20 h-20 bg-[#8C7B6D]/20 rounded-full flex items-center justify-center",
                children: f.icon
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 289,
                columnNumber: 123
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-2xl font-bold mb-4",
                children: f.title
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 289,
                columnNumber: 239
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-lg opacity-90",
                children: f.desc
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                lineNumber: 289,
                columnNumber: 293
            }, this)
        ]
    }, i, true, {
        fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
        lineNumber: 289,
        columnNumber: 10
    }, this);
}
function _HomeScrollToFeatures() {
    document.getElementById("features")?.scrollIntoView({
        behavior: "smooth"
    });
}
const ru = {
    hero: {
        title: [
            "Каждый Той",
            "Особенным",
            "Пусть Будет!"
        ],
        subtitle: "ToiLab — всё для свадьбы в одном приложении: ресторан, фотограф, ведущий, фейерверк, рассрочка и даже микрокредит."
    },
    features: {
        title: "Что умеет ToiLab?",
        items: [
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 304,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "1000+ услуг",
                desc: "Рестораны, фотографы, ведущие, декор"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 308,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Реальные отзывы",
                desc: "Только проверенные рейтинги"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 312,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Бронь за 2 минуты",
                desc: "Прямо в приложении"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Wallet$3e$__["Wallet"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 316,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Рассрочка",
                desc: "60% клиентов выбирают"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__["MessageCircle"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 320,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Чат с подрядчиком",
                desc: "Договор в приложении"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$smartphone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Smartphone$3e$__["Smartphone"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 324,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Свадьба в телефоне",
                desc: "Все заказы в одном месте"
            }
        ]
    },
    screenshots: {
        title: "Как выглядит приложение"
    },
    cta: {
        title: "Скачайте ToiLab",
        subtitle: "Бронируйте, оплачивайте, берите в рассрочку — за 2 минуты."
    }
};
const kz = {
    hero: {
        title: [
            "Әрбір Той",
            "Ерекше",
            "Болсын!"
        ],
        subtitle: "ToiLab — тойға қажетті барлық нәрсе бір қолданбада: мейрамхана, фотограф, ведущий, фейерверк, бөліп төлеу және микрокредит."
    },
    features: {
        title: "ToiLab немен көмектеседі?",
        items: [
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 345,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "1000+ қызмет",
                desc: "Мейрамханалар, фотографтар, ведущийлар, декор"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 349,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Нақты пікірлер",
                desc: "Тек расталған рейтингтер"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 353,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "2 минутта брондау",
                desc: "Тікелей қолданбада"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Wallet$3e$__["Wallet"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 357,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Бөліп төлеу",
                desc: "Клиенттердің 60%-ы таңдайды"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__["MessageCircle"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 361,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Подрядчикпен чат",
                desc: "Келісімшарт қолданбада"
            },
            {
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$smartphone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Smartphone$3e$__["Smartphone"], {
                    size: 48
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/page.js",
                    lineNumber: 365,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0)),
                title: "Той телефонда",
                desc: "Барлық тапсырыстар бір жерде"
            }
        ]
    },
    screenshots: {
        title: "Қолданба қалай көрінеді"
    },
    cta: {
        title: "ToiLab жүктеп алыңыз",
        subtitle: "Брондаңыз, төлеңіз, бөліп төлеңіз — 2 минутта."
    }
};
var _c, _c1;
__turbopack_context__.k.register(_c, "Ornament");
__turbopack_context__.k.register(_c1, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/download.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Download
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M12 15V3",
            key: "m9g1x1"
        }
    ],
    [
        "path",
        {
            d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
            key: "ih7n3h"
        }
    ],
    [
        "path",
        {
            d: "m7 10 5 5 5-5",
            key: "brsn70"
        }
    ]
];
const Download = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("download", __iconNode);
;
 //# sourceMappingURL=download.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/download.js [app-client] (ecmascript) <export default as Download>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Download",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/download.js [app-client] (ecmascript)");
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>ChevronDown
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "m6 9 6 6 6-6",
            key: "qrunsl"
        }
    ]
];
const ChevronDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("chevron-down", __iconNode);
;
 //# sourceMappingURL=chevron-down.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChevronDown",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript)");
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Search
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "m21 21-4.34-4.34",
            key: "14j7rj"
        }
    ],
    [
        "circle",
        {
            cx: "11",
            cy: "11",
            r: "8",
            key: "4ej97u"
        }
    ]
];
const Search = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("search", __iconNode);
;
 //# sourceMappingURL=search.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Search",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript)");
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/star.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Star
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
            key: "r04s7s"
        }
    ]
];
const Star = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("star", __iconNode);
;
 //# sourceMappingURL=star.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/star.js [app-client] (ecmascript) <export default as Star>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Star",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/star.js [app-client] (ecmascript)");
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Calendar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M8 2v4",
            key: "1cmpym"
        }
    ],
    [
        "path",
        {
            d: "M16 2v4",
            key: "4m81vk"
        }
    ],
    [
        "rect",
        {
            width: "18",
            height: "18",
            x: "3",
            y: "4",
            rx: "2",
            key: "1hopcy"
        }
    ],
    [
        "path",
        {
            d: "M3 10h18",
            key: "8toen8"
        }
    ]
];
const Calendar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("calendar", __iconNode);
;
 //# sourceMappingURL=calendar.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Calendar",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript)");
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/wallet.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Wallet
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",
            key: "18etb6"
        }
    ],
    [
        "path",
        {
            d: "M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4",
            key: "xoc0q4"
        }
    ]
];
const Wallet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("wallet", __iconNode);
;
 //# sourceMappingURL=wallet.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/wallet.js [app-client] (ecmascript) <export default as Wallet>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Wallet",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/wallet.js [app-client] (ecmascript)");
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>MessageCircle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
            key: "1sd12s"
        }
    ]
];
const MessageCircle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("message-circle", __iconNode);
;
 //# sourceMappingURL=message-circle.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-client] (ecmascript) <export default as MessageCircle>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MessageCircle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-client] (ecmascript)");
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/smartphone.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.553.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Smartphone
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "rect",
        {
            width: "14",
            height: "20",
            x: "5",
            y: "2",
            rx: "2",
            ry: "2",
            key: "1yt0o3"
        }
    ],
    [
        "path",
        {
            d: "M12 18h.01",
            key: "mhygvu"
        }
    ]
];
const Smartphone = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("smartphone", __iconNode);
;
 //# sourceMappingURL=smartphone.js.map
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/smartphone.js [app-client] (ecmascript) <export default as Smartphone>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Smartphone",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$smartphone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$smartphone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/smartphone.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=Documents_DEVELOPMENT_REACT_TOILABLANDING_toilab-landing_61537487._.js.map