globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/eac11_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_2099bd0f._.js",
    "static/chunks/eac11_next_dist_compiled_react-dom_f5741f08._.js",
    "static/chunks/eac11_next_dist_compiled_react-server-dom-turbopack_99f8b662._.js",
    "static/chunks/eac11_next_dist_compiled_next-devtools_index_6628165b.js",
    "static/chunks/eac11_next_dist_compiled_5d8e0131._.js",
    "static/chunks/eac11_next_dist_client_02db0f87._.js",
    "static/chunks/eac11_next_dist_098e5863._.js",
    "static/chunks/eac11_@swc_helpers_cjs_6ffee8b2._.js",
    "static/chunks/Documents_DEVELOPMENT_REACT_TOILABLANDING_toilab-landing_a0ff3932._.js",
    "static/chunks/turbopack-Documents_DEVELOPMENT_REACT_TOILABLANDING_toilab-landing_69c86df2._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];