module.exports = [
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/favicon.ico.mjs { IMAGE => \"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/favicon.ico.mjs { IMAGE => \"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js [app-rsc] (ecmascript)"));
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// app/contacts/page.js
__turbopack_context__.s([
    "default",
    ()=>Contacts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/mail.js [app-rsc] (ecmascript) <export default as Mail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/phone.js [app-rsc] (ecmascript) <export default as Phone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-rsc] (ecmascript) <export default as MapPin>");
;
;
function Contacts() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "py-24 px-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-5xl mx-auto text-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-5xl font-black mb-12",
                    children: "Контакты"
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
                    lineNumber: 8,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid md:grid-cols-3 gap-8 text-lg",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col items-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                    size: 48,
                                    className: "mb-4 text-[#8C7B6D]"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
                                    lineNumber: 11,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "font-bold",
                                    children: "Email"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
                                    lineNumber: 12,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: "mailto:support@toilab.kz",
                                    className: "text-[#4A3F35] hover:underline",
                                    children: "support@toilab.kz"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
                                    lineNumber: 13,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
                            lineNumber: 10,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col items-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                                    size: 48,
                                    className: "mb-4 text-[#8C7B6D]"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
                                    lineNumber: 16,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "font-bold",
                                    children: "Телефон"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
                                    lineNumber: 17,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: "tel:+77071234567",
                                    className: "text-[#4A3F35] hover:underline",
                                    children: "+7 (707) 123-45-67"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
                                    lineNumber: 18,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
                            lineNumber: 15,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col items-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"], {
                                    size: 48,
                                    className: "mb-4 text-[#8C7B6D]"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
                                    lineNumber: 21,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "font-bold",
                                    children: "Адрес"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
                                    lineNumber: 22,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: "Алматы, ул. Абая 123, офис 45"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
                                    lineNumber: 23,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
                            lineNumber: 20,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
                    lineNumber: 9,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
            lineNumber: 7,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js",
        lineNumber: 6,
        columnNumber: 5
    }, this);
}
}),
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/contacts/page.js [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__f594a0b4._.js.map