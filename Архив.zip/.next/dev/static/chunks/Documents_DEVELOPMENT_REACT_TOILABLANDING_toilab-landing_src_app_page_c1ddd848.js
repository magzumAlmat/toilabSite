(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Documents_DEVELOPMENT_REACT_TOILABLANDING_toilab-landing_61537487._.js"
],
    source: "dynamic"
});
