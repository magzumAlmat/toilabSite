(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// app/layout.js
__turbopack_context__.s([
    "LangContext",
    ()=>LangContext,
    "default",
    ()=>RootLayout
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/menu.js [app-client] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const LangContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])();
function RootLayout(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(56);
    if ($[0] !== "6fe4d33efd1648281f7efbd6b970fa1a16756c2761fc02d27069b8712303da49") {
        for(let $i = 0; $i < 56; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "6fe4d33efd1648281f7efbd6b970fa1a16756c2761fc02d27069b8712303da49";
    }
    const { children } = t0;
    const [lang, setLang] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("ru");
    const [mobileMenuOpen, setMobileMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const t = lang === "ru" ? ru : kz;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("head", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                    href: "https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap",
                    rel: "stylesheet"
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
                    lineNumber: 29,
                    columnNumber: 16
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("title", {
                    children: "Toilab — Всё для вашего тоя"
                }, void 0, false, {
                    fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
                    lineNumber: 29,
                    columnNumber: 130
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 29,
            columnNumber: 10
        }, this);
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            fontFamily: "'Roboto', sans-serif"
        };
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    let t3;
    if ($[3] !== lang) {
        t3 = {
            lang,
            setLang
        };
        $[3] = lang;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: "/",
            className: "flex items-center gap-2",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                src: "/images/logo.png",
                alt: "ToiLab",
                width: 100,
                height: 80,
                className: "drop-shadow"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
                lineNumber: 56,
                columnNumber: 61
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 56,
            columnNumber: 10
        }, this);
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] !== t.nav.home) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: "/",
            className: "text-lg font-medium hover:text-[#8C7B6D] transition",
            children: t.nav.home
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 63,
            columnNumber: 10
        }, this);
        $[6] = t.nav.home;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    let t6;
    if ($[8] !== t.nav.contacts) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: "/contacts",
            className: "text-lg font-medium hover:text-[#8C7B6D] transition",
            children: t.nav.contacts
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 71,
            columnNumber: 10
        }, this);
        $[8] = t.nav.contacts;
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    let t7;
    if ($[10] !== t.nav.privacy) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: "/privacy",
            className: "text-lg font-medium hover:text-[#8C7B6D] transition",
            children: t.nav.privacy
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 79,
            columnNumber: 10
        }, this);
        $[10] = t.nav.privacy;
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    let t8;
    if ($[12] !== t5 || $[13] !== t6 || $[14] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
            className: "hidden md:flex items-center gap-8",
            children: [
                t5,
                t6,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 87,
            columnNumber: 10
        }, this);
        $[12] = t5;
        $[13] = t6;
        $[14] = t7;
        $[15] = t8;
    } else {
        t8 = $[15];
    }
    let t9;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = ({
            "RootLayout[<button>.onClick]": ()=>setLang("kz")
        })["RootLayout[<button>.onClick]"];
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    const t10 = `px-4 py-1.5 rounded-full text-sm font-bold transition ${lang === "kz" ? "bg-[#4A3F35] text-white" : "text-[#4A3F35]"}`;
    let t11;
    if ($[17] !== t10) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: t9,
            className: t10,
            children: "ҚАЗ"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 107,
            columnNumber: 11
        }, this);
        $[17] = t10;
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    let t12;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = ({
            "RootLayout[<button>.onClick]": ()=>setLang("ru")
        })["RootLayout[<button>.onClick]"];
        $[19] = t12;
    } else {
        t12 = $[19];
    }
    const t13 = `px-4 py-1.5 rounded-full text-sm font-bold transition ${lang === "ru" ? "bg-[#4A3F35] text-white" : "text-[#4A3F35]"}`;
    let t14;
    if ($[20] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: t12,
            className: t13,
            children: "РУС"
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 125,
            columnNumber: 11
        }, this);
        $[20] = t13;
        $[21] = t14;
    } else {
        t14 = $[21];
    }
    let t15;
    if ($[22] !== t11 || $[23] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "hidden md:flex items-center gap-2 bg-[#F5F0E9] rounded-full p-1",
            children: [
                t11,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 133,
            columnNumber: 11
        }, this);
        $[22] = t11;
        $[23] = t14;
        $[24] = t15;
    } else {
        t15 = $[24];
    }
    let t16;
    if ($[25] !== mobileMenuOpen) {
        t16 = ({
            "RootLayout[<button>.onClick]": ()=>setMobileMenuOpen(!mobileMenuOpen)
        })["RootLayout[<button>.onClick]"];
        $[25] = mobileMenuOpen;
        $[26] = t16;
    } else {
        t16 = $[26];
    }
    let t17;
    if ($[27] !== mobileMenuOpen) {
        t17 = mobileMenuOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
            size: 28
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 152,
            columnNumber: 28
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
            size: 28
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 152,
            columnNumber: 46
        }, this);
        $[27] = mobileMenuOpen;
        $[28] = t17;
    } else {
        t17 = $[28];
    }
    let t18;
    if ($[29] !== t16 || $[30] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: t16,
            className: "md:hidden p-2",
            children: t17
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 160,
            columnNumber: 11
        }, this);
        $[29] = t16;
        $[30] = t17;
        $[31] = t18;
    } else {
        t18 = $[31];
    }
    let t19;
    if ($[32] !== t15 || $[33] !== t18 || $[34] !== t8) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-7xl mx-auto px-4 py-4 flex items-center justify-between",
            children: [
                t4,
                t8,
                t15,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 169,
            columnNumber: 11
        }, this);
        $[32] = t15;
        $[33] = t18;
        $[34] = t8;
        $[35] = t19;
    } else {
        t19 = $[35];
    }
    let t20;
    if ($[36] !== lang || $[37] !== mobileMenuOpen || $[38] !== t.nav.contacts || $[39] !== t.nav.home || $[40] !== t.nav.privacy) {
        t20 = mobileMenuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "md:hidden absolute top-full left-0 right-0 bg-white shadow-lg border-t",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-6 py-4 space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        className: "block text-lg font-medium",
                        onClick: {
                            "RootLayout[<Link>.onClick]": ()=>setMobileMenuOpen(false)
                        }["RootLayout[<Link>.onClick]"],
                        children: t.nav.home
                    }, void 0, false, {
                        fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
                        lineNumber: 179,
                        columnNumber: 154
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/contacts",
                        className: "block text-lg font-medium",
                        onClick: {
                            "RootLayout[<Link>.onClick]": ()=>setMobileMenuOpen(false)
                        }["RootLayout[<Link>.onClick]"],
                        children: t.nav.contacts
                    }, void 0, false, {
                        fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
                        lineNumber: 181,
                        columnNumber: 61
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/privacy",
                        className: "block text-lg font-medium",
                        onClick: {
                            "RootLayout[<Link>.onClick]": ()=>setMobileMenuOpen(false)
                        }["RootLayout[<Link>.onClick]"],
                        children: t.nav.privacy
                    }, void 0, false, {
                        fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
                        lineNumber: 183,
                        columnNumber: 65
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2 pt-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: {
                                    "RootLayout[<button>.onClick]": ()=>{
                                        setLang("kz");
                                        setMobileMenuOpen(false);
                                    }
                                }["RootLayout[<button>.onClick]"],
                                className: `px-4 py-1.5 rounded-full text-sm font-bold ${lang === "kz" ? "bg-[#4A3F35] text-white" : "text-[#4A3F35] bg-[#F5F0E9]"}`,
                                children: "ҚАЗ"
                            }, void 0, false, {
                                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
                                lineNumber: 185,
                                columnNumber: 97
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: {
                                    "RootLayout[<button>.onClick]": ()=>{
                                        setLang("ru");
                                        setMobileMenuOpen(false);
                                    }
                                }["RootLayout[<button>.onClick]"],
                                className: `px-4 py-1.5 rounded-full text-sm font-bold ${lang === "ru" ? "bg-[#4A3F35] text-white" : "text-[#4A3F35] bg-[#F5F0E9]"}`,
                                children: "РУС"
                            }, void 0, false, {
                                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
                                lineNumber: 190,
                                columnNumber: 192
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
                        lineNumber: 185,
                        columnNumber: 64
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
                lineNumber: 179,
                columnNumber: 117
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 179,
            columnNumber: 29
        }, this);
        $[36] = lang;
        $[37] = mobileMenuOpen;
        $[38] = t.nav.contacts;
        $[39] = t.nav.home;
        $[40] = t.nav.privacy;
        $[41] = t20;
    } else {
        t20 = $[41];
    }
    let t21;
    if ($[42] !== t19 || $[43] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
            className: "fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm shadow-md",
            children: [
                t19,
                t20
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 207,
            columnNumber: 11
        }, this);
        $[42] = t19;
        $[43] = t20;
        $[44] = t21;
    } else {
        t21 = $[44];
    }
    let t22;
    if ($[45] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white py-4 border-b-8 border-[#4A3F35] mt-20",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-7xl mx-auto px-4"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
                lineNumber: 216,
                columnNumber: 76
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 216,
            columnNumber: 11
        }, this);
        $[45] = t22;
    } else {
        t22 = $[45];
    }
    let t23;
    if ($[46] !== children) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
            children: children
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 223,
            columnNumber: 11
        }, this);
        $[46] = children;
        $[47] = t23;
    } else {
        t23 = $[47];
    }
    let t24;
    if ($[48] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white py-4 border-t-8 border-[#4A3F35]",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-7xl mx-auto px-4"
            }, void 0, false, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
                lineNumber: 231,
                columnNumber: 70
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 231,
            columnNumber: 11
        }, this);
        $[48] = t24;
    } else {
        t24 = $[48];
    }
    let t25;
    if ($[49] !== t21 || $[50] !== t23 || $[51] !== t3) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("body", {
            className: "bg-gradient-to-b from-[#F5F0E9] to-[#E8DED3] text-[#4A3F35]",
            style: t2,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LangContext.Provider, {
                value: t3,
                children: [
                    t21,
                    t22,
                    t23,
                    t24
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
                lineNumber: 238,
                columnNumber: 100
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 238,
            columnNumber: 11
        }, this);
        $[49] = t21;
        $[50] = t23;
        $[51] = t3;
        $[52] = t25;
    } else {
        t25 = $[52];
    }
    let t26;
    if ($[53] !== lang || $[54] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$DEVELOPMENT$2f$REACT$2f$TOILABLANDING$2f$toilab$2d$landing$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("html", {
            lang: lang,
            children: [
                t1,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/src/app/layout.js",
            lineNumber: 248,
            columnNumber: 11
        }, this);
        $[53] = lang;
        $[54] = t25;
        $[55] = t26;
    } else {
        t26 = $[55];
    }
    return t26;
}
_s(RootLayout, "SSVvzwoqfLurgSMlLW2q3Ggy2/Q=");
_c = RootLayout;
// Тексты навигации
const ru = {
    nav: {
        home: "Главная",
        contacts: "Контакты",
        privacy: "Политика конфиденциальности"
    }
};
const kz = {
    nav: {
        home: "Басты бет",
        contacts: "Байланыс",
        privacy: "Құпиялылық саясаты"
    }
};
var _c;
__turbopack_context__.k.register(_c, "RootLayout");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=Documents_DEVELOPMENT_REACT_TOILABLANDING_toilab-landing_src_app_layout_0d40f7cc.js.map