module.exports = [
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/.next-internal/server/app/contacts/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=8616d_toilab-landing__next-internal_server_app_contacts_page_actions_c9f07c93.js.map