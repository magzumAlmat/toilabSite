module.exports = [
"[project]/Documents/DEVELOPMENT/REACT/TOILABLANDING/toilab-landing/.next-internal/server/app/privacy/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=8616d_toilab-landing__next-internal_server_app_privacy_page_actions_86fad9c3.js.map